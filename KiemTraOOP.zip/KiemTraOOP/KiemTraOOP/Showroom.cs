﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KiemTraOOP
{
    class Showroom
    {
        List<Car> bmws;
        List<Car> hds;

        private string name;
        private double revenue;

        public Showroom()
        {
            Name = "";
            Revenue = 0;
            bmws = new List<Car>();
            hds = new List<Car>();
        }

        public Showroom(string _name, double _revenue)
        {
            bmws = new List<Car>();
            hds = new List<Car>();
            name = _name;
            revenue = _revenue;
        }

        public Showroom(string _name)
        {
            bmws = new List<Car>();
            hds = new List<Car>();
            name = _name;
            revenue = 0;
        }

        public string Name { get => name; set => name = value; }
        public double Revenue { get => revenue; set => revenue = value; }

        public void Import()
        {
            Console.Write("Nhap so luong xe: ");
            int n = Int32.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write("Loai xe: BMW => 1, Honda => 2 \nNhap loai xe: ");
                int type = Int32.Parse(Console.ReadLine());
                Console.WriteLine();

                if (type == 1)
                {                  
                    Console.WriteLine("============ Xe BMW ============");
                    Console.Write("Vui long nhap gia xe: ");
                    double pr = double.Parse(Console.ReadLine());
                    Console.Write("Vui long nhap nam san xuat: ");
                    int yr = int.Parse(Console.ReadLine());

                    //Console.WriteLine();

                    Car bmw = new BMW(pr, yr);
                    Console.WriteLine();

                    bmws.Add(bmw);
                }
                else if (type == 2)
                {
                    Car hd;
                    Console.WriteLine("============ Xe Honda ============");
                    Console.Write("Vui long nhap gia xe: ");
                    double pr = double.Parse(Console.ReadLine());
                    Console.Write("Vui long nhap nam san xuat: ");
                    int yr = int.Parse(Console.ReadLine());

                    //Console.WriteLine();

                    hd = new Honda(pr, yr);
                    Console.WriteLine();

                    hds.Add(hd);
                }
                else
                {
                    Console.WriteLine("Loai xe khong phu hop vui long nhap lai!");
                    i--;
                }
            }
        }

        public void Show()
        {
            foreach (Car hd in hds)
            {
                hd.Show();
            }

            foreach (Car bmw in bmws)
            {
                bmw.Show();
            }
        }

        public double Total()
        {
            double total = 0;

            foreach (Car hd in hds)
            {
                total += hd.Discount();
            }

            foreach (Car bmw in bmws)
            {
                total += bmw.Discount();
            }

            return total;
        }

        public double Max()
        {
            double max = 0;

            foreach (Car bmw in bmws)
            {
                if (bmw.Discount() > max)
                    max = bmw.Discount();
            }

            return max;
        }
    }
}
