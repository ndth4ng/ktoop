﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KiemTraOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            Showroom sr = new Showroom("Hoang Hai");

            sr.Import();

            Console.WriteLine("==== Xe trong Showroom ====");

            sr.Show();
             
            Console.WriteLine("Tong gia tri xe cua Showroom = "+ sr.Total());

            Console.WriteLine("Xe BMW co gia cao nhat = " + sr.Max());
        }
    }
}
